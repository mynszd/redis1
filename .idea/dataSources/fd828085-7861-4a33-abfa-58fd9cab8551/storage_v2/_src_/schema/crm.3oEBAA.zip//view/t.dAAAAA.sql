create view t as
select `crm`.`bas_dict`.`dict_id`          AS `dict_id`,
       `crm`.`bas_dict`.`dict_type`        AS `dict_type`,
       `crm`.`bas_dict`.`dict_item`        AS `dict_item`,
       `crm`.`bas_dict`.`dict_value`       AS `dict_value`,
       `crm`.`bas_dict`.`dict_is_editable` AS `dict_is_editable`,
       `crm`.`bas_dict`.`dict_status`      AS `dict_status`
from `crm`.`bas_dict`;

